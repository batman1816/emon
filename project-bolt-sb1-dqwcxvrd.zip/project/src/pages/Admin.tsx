import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Upload, 
  FileText, 
  ChevronDown, 
  ChevronRight, 
  Plus, 
  Trash2, 
  Edit3,
  Save,
  X,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { subjects, paperSessions, papers, Subject, PaperSession, Paper } from '../data/mockData';

interface UploadedFile {
  id: string;
  file: File;
  subjectId: string;
  sessionId: string;
  type: 'QP' | 'MS' | 'SAM';
  status: 'pending' | 'uploaded' | 'error';
}

const Admin: React.FC = () => {
  const [selectedLevel, setSelectedLevel] = useState<'IGCSE' | 'IAL'>('IGCSE');
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [selectedSession, setSelectedSession] = useState<string | null>(null);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const levelSubjects = subjects.filter(subject => subject.level === selectedLevel);
  const subjectSessions = selectedSubject ? paperSessions.filter(session => session.subjectId === selectedSubject) : [];
  const sessionPapers = selectedSession ? papers.filter(paper => paper.sessionId === selectedSession) : [];

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 3000);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>, type: 'QP' | 'MS' | 'SAM') => {
    const file = event.target.files?.[0];
    if (!file || !selectedSubject || !selectedSession) {
      showNotification('error', 'Please select a subject and session first');
      return;
    }

    if (file.type !== 'application/pdf') {
      showNotification('error', 'Please upload only PDF files');
      return;
    }

    const uploadedFile: UploadedFile = {
      id: Date.now().toString(),
      file,
      subjectId: selectedSubject,
      sessionId: selectedSession,
      type,
      status: 'pending'
    };

    setUploadedFiles(prev => [...prev, uploadedFile]);
    simulateUpload(uploadedFile.id);
  };

  const simulateUpload = async (fileId: string) => {
    setIsUploading(true);
    
    // Simulate upload delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setUploadedFiles(prev => 
      prev.map(file => 
        file.id === fileId 
          ? { ...file, status: Math.random() > 0.1 ? 'uploaded' : 'error' }
          : file
      )
    );
    
    setIsUploading(false);
    
    const file = uploadedFiles.find(f => f.id === fileId);
    if (file) {
      showNotification('success', `${file.type} uploaded successfully!`);
    }
  };

  const removeFile = (fileId: string) => {
    setUploadedFiles(prev => prev.filter(file => file.id !== fileId));
  };

  const getFileStatusIcon = (status: string) => {
    switch (status) {
      case 'uploaded':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return <div className="h-5 w-5 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Notification */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className={`fixed top-4 right-4 z-50 px-6 py-3 rounded-lg shadow-lg ${
              notification.type === 'success' 
                ? 'bg-green-500 text-white' 
                : 'bg-red-500 text-white'
            }`}
          >
            {notification.message}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Sidebar Navigation */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-md p-6 sticky top-8">
              
              {/* Level Selection */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Exam Level</h3>
                <div className="flex space-x-2">
                  <button
                    onClick={() => {
                      setSelectedLevel('IGCSE');
                      setSelectedSubject(null);
                      setSelectedSession(null);
                    }}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors duration-200 ${
                      selectedLevel === 'IGCSE'
                        ? 'bg-green-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    IGCSE
                  </button>
                  <button
                    onClick={() => {
                      setSelectedLevel('IAL');
                      setSelectedSubject(null);
                      setSelectedSession(null);
                    }}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors duration-200 ${
                      selectedLevel === 'IAL'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    IAL
                  </button>
                </div>
              </div>

              {/* Subject Selection */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Subjects</h3>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {levelSubjects.map((subject) => (
                    <button
                      key={subject.id}
                      onClick={() => {
                        setSelectedSubject(subject.id);
                        setSelectedSession(null);
                      }}
                      className={`w-full text-left p-3 rounded-lg transition-colors duration-200 ${
                        selectedSubject === subject.id
                          ? selectedLevel === 'IGCSE' 
                            ? 'bg-green-100 text-green-800 border-2 border-green-300'
                            : 'bg-blue-100 text-blue-800 border-2 border-blue-300'
                          : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      <div className="font-medium">{subject.name}</div>
                      <div className="text-sm opacity-75">{subject.code}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Session Selection */}
              {selectedSubject && (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Sessions</h3>
                  <div className="space-y-2">
                    {subjectSessions.map((session) => (
                      <button
                        key={session.id}
                        onClick={() => setSelectedSession(session.id)}
                        className={`w-full text-left p-3 rounded-lg transition-colors duration-200 ${
                          selectedSession === session.id
                            ? selectedLevel === 'IGCSE'
                              ? 'bg-green-100 text-green-800 border-2 border-green-300'
                              : 'bg-blue-100 text-blue-800 border-2 border-blue-300'
                            : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        <div className="font-medium">{session.session}</div>
                        <div className="text-sm opacity-75">{session.year}</div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {!selectedSubject ? (
              <div className="bg-white rounded-xl shadow-md p-8 text-center">
                <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Select a Subject</h2>
                <p className="text-gray-600">Choose an exam level and subject to start uploading papers</p>
              </div>
            ) : !selectedSession ? (
              <div className="bg-white rounded-xl shadow-md p-8 text-center">
                <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Select a Session</h2>
                <p className="text-gray-600">Choose a session to upload papers for</p>
              </div>
            ) : (
              <div className="space-y-6">
                
                {/* Upload Section */}
                <div className="bg-white rounded-xl shadow-md p-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">
                    Upload Papers - {levelSubjects.find(s => s.id === selectedSubject)?.name} 
                    ({subjectSessions.find(s => s.id === selectedSession)?.session})
                  </h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    
                    {/* Question Paper Upload */}
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary-400 transition-colors duration-200">
                      <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">Question Paper</h3>
                      <p className="text-sm text-gray-600 mb-4">Upload QP (PDF only)</p>
                      <input
                        type="file"
                        accept=".pdf"
                        onChange={(e) => handleFileUpload(e, 'QP')}
                        className="hidden"
                        id="qp-upload"
                      />
                      <label
                        htmlFor="qp-upload"
                        className="inline-flex items-center px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 cursor-pointer transition-colors duration-200"
                      >
                        <Plus className="mr-2 h-4 w-4" />
                        Upload QP
                      </label>
                    </div>

                    {/* Mark Scheme Upload */}
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary-400 transition-colors duration-200">
                      <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">Mark Scheme</h3>
                      <p className="text-sm text-gray-600 mb-4">Upload MS (PDF only)</p>
                      <input
                        type="file"
                        accept=".pdf"
                        onChange={(e) => handleFileUpload(e, 'MS')}
                        className="hidden"
                        id="ms-upload"
                      />
                      <label
                        htmlFor="ms-upload"
                        className="inline-flex items-center px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 cursor-pointer transition-colors duration-200"
                      >
                        <Plus className="mr-2 h-4 w-4" />
                        Upload MS
                      </label>
                    </div>

                    {/* Specimen Paper Upload */}
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary-400 transition-colors duration-200">
                      <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">Specimen Paper</h3>
                      <p className="text-sm text-gray-600 mb-4">Upload SAM (PDF only)</p>
                      <input
                        type="file"
                        accept=".pdf"
                        onChange={(e) => handleFileUpload(e, 'SAM')}
                        className="hidden"
                        id="sam-upload"
                      />
                      <label
                        htmlFor="sam-upload"
                        className="inline-flex items-center px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 cursor-pointer transition-colors duration-200"
                      >
                        <Plus className="mr-2 h-4 w-4" />
                        Upload SAM
                      </label>
                    </div>
                  </div>
                </div>

                {/* Upload Queue */}
                {uploadedFiles.length > 0 && (
                  <div className="bg-white rounded-xl shadow-md p-8">
                    <h3 className="text-xl font-bold text-gray-900 mb-6">Upload Queue</h3>
                    <div className="space-y-4">
                      {uploadedFiles.map((file) => (
                        <motion.div
                          key={file.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                        >
                          <div className="flex items-center space-x-4">
                            {getFileStatusIcon(file.status)}
                            <div>
                              <div className="font-medium text-gray-900">
                                {file.file.name}
                              </div>
                              <div className="text-sm text-gray-600">
                                {file.type} • {(file.file.size / 1024 / 1024).toFixed(2)} MB
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                              file.status === 'uploaded' 
                                ? 'bg-green-100 text-green-800'
                                : file.status === 'error'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }`}>
                              {file.status === 'uploaded' ? 'Uploaded' : 
                               file.status === 'error' ? 'Error' : 'Uploading...'}
                            </span>
                            <button
                              onClick={() => removeFile(file.id)}
                              className="p-2 text-gray-400 hover:text-red-600 transition-colors duration-200"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Existing Papers */}
                <div className="bg-white rounded-xl shadow-md p-8">
                  <h3 className="text-xl font-bold text-gray-900 mb-6">Existing Papers</h3>
                  {sessionPapers.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {['QP', 'MS', 'SAM'].map((type) => {
                        const paper = sessionPapers.find(p => p.type === type);
                        return (
                          <div key={type} className="p-4 border rounded-lg">
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-medium text-gray-900">{type}</h4>
                              {paper?.available ? (
                                <CheckCircle className="h-5 w-5 text-green-500" />
                              ) : (
                                <AlertCircle className="h-5 w-5 text-gray-400" />
                              )}
                            </div>
                            {paper ? (
                              <div>
                                <p className="text-sm text-gray-600 mb-2">{paper.fileName}</p>
                                <div className="flex space-x-2">
                                  <a
                                    href={paper.url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded"
                                  >
                                    View
                                  </a>
                                  <button className="text-xs bg-red-100 text-red-800 px-2 py-1 rounded hover:bg-red-200">
                                    Delete
                                  </button>
                                </div>
                              </div>
                            ) : (
                              <p className="text-sm text-gray-500">Not uploaded</p>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="text-gray-600">No papers uploaded for this session yet.</p>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admin;