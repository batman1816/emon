import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Home, Search, BookOpen, AlertTriangle } from 'lucide-react';

const NotFound: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="max-w-md mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* Mascot/Icon */}
          <div className="w-32 h-32 mx-auto mb-8 bg-primary-100 rounded-full flex items-center justify-center">
            <AlertTriangle className="h-16 w-16 text-primary-600" />
          </div>

          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Oops! Paper Not Found
          </h1>
          
          <p className="text-xl text-gray-600 mb-8">
            Looks like we don't have this resource yet! Our team is constantly updating our database with new papers.
          </p>

          <div className="space-y-4">
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Link
                to="/"
                className="inline-flex items-center px-6 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200 font-medium"
              >
                <Home className="mr-2 h-5 w-5" />
                Back to Homepage
              </Link>
            </motion.div>

            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Link
                to="/search"
                className="inline-flex items-center px-6 py-3 bg-white text-primary-600 border-2 border-primary-600 rounded-lg hover:bg-primary-50 transition-colors duration-200 font-medium"
              >
                <Search className="mr-2 h-5 w-5" />
                Search Papers
              </Link>
            </motion.div>
          </div>

          <div className="mt-12 pt-8 border-t border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Try browsing our subjects:
            </h2>
            <div className="flex flex-wrap justify-center gap-4">
              <Link
                to="/igcse"
                className="inline-flex items-center px-4 py-2 bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition-colors duration-200"
              >
                <BookOpen className="mr-2 h-4 w-4" />
                IGCSE Papers
              </Link>
              <Link
                to="/ial"
                className="inline-flex items-center px-4 py-2 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition-colors duration-200"
              >
                <BookOpen className="mr-2 h-4 w-4" />
                IAL Papers
              </Link>
            </div>
          </div>

          <div className="mt-8 p-6 bg-yellow-50 rounded-lg">
            <p className="text-sm text-yellow-800">
              <strong>Missing a paper?</strong> Join our Discord community to request specific papers or get notified when new ones are added!
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default NotFound;