import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search as SearchIcon, Download, FileText, AlertCircle } from 'lucide-react';
import { searchPapers } from '../data/mockData';

const Search: React.FC = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      const searchResults = searchPapers(query.trim());
      setResults(searchResults);
      setHasSearched(true);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
      },
    },
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="bg-gradient-to-r from-purple-600 to-purple-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Search Papers</h1>
            <p className="text-xl text-purple-100 max-w-3xl mx-auto">
              Find specific papers, subjects, and resources across our entire database
            </p>
          </motion.div>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Search Form */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="bg-white rounded-xl shadow-md p-8 mb-8"
        >
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="relative">
              <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search for subjects, topics, or paper types..."
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>
            <motion.button
              type="submit"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors duration-200 font-medium"
            >
              Search Papers
            </motion.button>
          </form>
        </motion.div>

        {/* Results */}
        {hasSearched && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
          >
            {results.length > 0 ? (
              <div className="bg-white rounded-xl shadow-md p-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">
                  Search Results ({results.length})
                </h2>
                <motion.div
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  className="space-y-4"
                >
                  {results.map((result, index) => (
                    <motion.div
                      key={index}
                      variants={itemVariants}
                      className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-200"
                    >
                      <div className="flex items-center space-x-4">
                        <FileText className="h-8 w-8 text-purple-600" />
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            {result.level} {result.subject}
                          </h3>
                          <p className="text-sm text-gray-600">
                            {result.session} • {result.type}
                          </p>
                          <p className="text-xs text-gray-500">{result.fileName}</p>
                        </div>
                      </div>
                      <motion.a
                        href={result.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors duration-200"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        <Download className="mr-2 h-4 w-4" />
                        Download
                      </motion.a>
                    </motion.div>
                  ))}
                </motion.div>
              </div>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="bg-white rounded-xl shadow-md p-8 text-center"
              >
                <div className="w-32 h-32 mx-auto mb-6 bg-gray-100 rounded-full flex items-center justify-center">
                  <AlertCircle className="h-16 w-16 text-gray-400" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">No Results Found</h3>
                <p className="text-gray-600 mb-6">
                  We couldn't find any papers matching "{query}". Try searching with different keywords or browse our subjects directly.
                </p>
                <div className="space-y-4">
                  <p className="text-sm text-gray-500">Try searching for:</p>
                  <div className="flex flex-wrap justify-center gap-2">
                    {['Biology', 'Chemistry', 'Physics', 'Mathematics', 'English'].map((subject) => (
                      <button
                        key={subject}
                        onClick={() => {
                          setQuery(subject);
                          const searchResults = searchPapers(subject);
                          setResults(searchResults);
                        }}
                        className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm hover:bg-purple-200 transition-colors duration-200"
                      >
                        {subject}
                      </button>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </motion.div>
        )}

        {/* Help Section */}
        {!hasSearched && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-white rounded-xl shadow-md p-8"
          >
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Search Tips</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Subject Names</h3>
                <p className="text-gray-600 text-sm">
                  Search for specific subjects like "Biology", "Chemistry", or "Mathematics"
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Paper Types</h3>
                <p className="text-gray-600 text-sm">
                  Use "QP" for Question Papers, "MS" for Mark Schemes, or "SAM" for Specimens
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Exam Levels</h3>
                <p className="text-gray-600 text-sm">
                  Include "IGCSE" or "IAL" to filter by examination level
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Sessions</h3>
                <p className="text-gray-600 text-sm">
                  Search by session like "Oct 2023", "June 2023", or specific years
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default Search;