import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronRight, BookOpen, FileText, Clock } from 'lucide-react';
import { getSubjectsByLevel, getSessionsBySubject, getPapersBySession } from '../data/mockData';

const IGCSE: React.FC = () => {
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const subjects = getSubjectsByLevel('IGCSE');

  const toggleSubject = (subjectId: string) => {
    setSelectedSubject(selectedSubject === subjectId ? null : subjectId);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: {
      opacity: 1,
      x: 0,
      transition: {
        duration: 0.3,
      },
    },
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="bg-gradient-to-r from-green-600 to-green-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4">IGCSE Past Papers</h1>
            <p className="text-xl text-green-100 max-w-3xl mx-auto">
              Access comprehensive IGCSE past papers, mark schemes, and specimen papers for all subjects
            </p>
          </motion.div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="lg:w-1/3"
          >
            <div className="bg-white rounded-xl shadow-md p-6 sticky top-24">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Subjects</h2>
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className="space-y-2"
              >
                {subjects.map((subject) => (
                  <motion.div key={subject.id} variants={itemVariants}>
                    <button
                      onClick={() => toggleSubject(subject.id)}
                      className="w-full flex items-center justify-between p-3 rounded-lg text-left hover:bg-gray-50 transition-colors duration-200"
                    >
                      <div className="flex items-center space-x-3">
                        <BookOpen className="h-5 w-5 text-green-600" />
                        <div>
                          <div className="font-medium text-gray-900">{subject.name}</div>
                          <div className="text-sm text-gray-500">{subject.code}</div>
                        </div>
                      </div>
                      {selectedSubject === subject.id ? (
                        <ChevronDown className="h-5 w-5 text-gray-400" />
                      ) : (
                        <ChevronRight className="h-5 w-5 text-gray-400" />
                      )}
                    </button>
                    
                    <AnimatePresence>
                      {selectedSubject === subject.id && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.3 }}
                          className="ml-8 mt-2 space-y-2"
                        >
                          {getSessionsBySubject(subject.id).map((session) => (
                            <Link
                              key={session.id}
                              to={`/igcse/${subject.name.toLowerCase().replace(/\s+/g, '-')}`}
                              className="block p-2 rounded-md text-sm text-gray-600 hover:text-green-600 hover:bg-green-50 transition-colors duration-200"
                            >
                              <div className="flex items-center space-x-2">
                                <Clock className="h-4 w-4" />
                                <span>{session.session}</span>
                              </div>
                            </Link>
                          ))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                ))}
              </motion.div>
            </div>
          </motion.div>

          {/* Main Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="lg:w-2/3"
          >
            <div className="bg-white rounded-xl shadow-md p-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Featured Subjects</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {subjects.slice(0, 6).map((subject, index) => (
                  <motion.div
                    key={subject.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    whileHover={{ y: -5 }}
                    className="group"
                  >
                    <Link
                      to={`/igcse/${subject.name.toLowerCase().replace(/\s+/g, '-')}`}
                      className="block p-6 bg-gradient-to-br from-green-50 to-green-100 rounded-xl hover:from-green-100 hover:to-green-200 transition-all duration-200 shadow-sm hover:shadow-md"
                    >
                      <div className="flex items-center space-x-4 mb-4">
                        <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center">
                          <FileText className="h-6 w-6 text-white" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900 group-hover:text-green-700">
                            {subject.name}
                          </h3>
                          <p className="text-sm text-gray-500">{subject.code}</p>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">
                          {getSessionsBySubject(subject.id).length} sessions available
                        </span>
                        <div className="flex items-center space-x-1">
                          {getSessionsBySubject(subject.id).slice(0, 3).map((session) => (
                            <div key={session.id} className="flex space-x-1">
                              {getPapersBySession(session.id).map((paper) => (
                                <div
                                  key={paper.id}
                                  className={`w-2 h-2 rounded-full ${
                                    paper.available ? 'bg-green-500' : 'bg-gray-300'
                                  }`}
                                />
                              ))}
                            </div>
                          ))}
                        </div>
                      </div>
                    </Link>
                  </motion.div>
                ))}
              </div>
              
              <div className="mt-8 text-center">
                <p className="text-gray-600 mb-4">
                  Don't see your subject? Use the sidebar to browse all available subjects or try our search.
                </p>
                <Link
                  to="/search"
                  className="inline-flex items-center px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
                >
                  <FileText className="mr-2 h-5 w-5" />
                  Search All Papers
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default IGCSE;