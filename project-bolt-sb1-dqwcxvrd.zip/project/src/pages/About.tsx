import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Users, Target, Award } from 'lucide-react';

const About: React.FC = () => {
  const stats = [
    { number: '50,000+', label: 'Students Helped', icon: Users },
    { number: '10,000+', label: 'Papers Available', icon: BookOpen },
    { number: '6', label: 'Years of Service', icon: Award },
    { number: '100+', label: 'Subjects Covered', icon: Target },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
      },
    },
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-600 to-primary-800 text-white py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-6xl font-bold mb-6">About Paperlords</h1>
            <p className="text-xl md:text-2xl text-primary-100">
              Empowering students worldwide with comprehensive access to educational resources
            </p>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                className="text-center p-6 bg-white rounded-xl shadow-md"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-100 rounded-full mb-4">
                  <stat.icon className="h-8 w-8 text-primary-600" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="prose prose-lg mx-auto"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-8 text-center">Our Story</h2>
            
            <div className="space-y-6 text-gray-700 leading-relaxed">
              <p>
                Founded in 2018, Paperlords began as a simple idea: to democratize access to quality educational 
                resources for students worldwide. What started as a small collection of past papers has grown 
                into one of the most comprehensive databases of IGCSE and IAL examination materials.
              </p>
              
              <p>
                Our mission is rooted in the belief that every student deserves access to the tools they need 
                to succeed. We understand the challenges that students face when preparing for examinations, 
                especially when quality resources are scattered across different platforms or behind paywalls.
              </p>
              
              <p>
                Over the years, we've built a community of over 50,000 students who rely on Paperlords for 
                their examination preparation. Our platform hosts thousands of past papers, mark schemes, 
                and specimen papers, all meticulously organized and regularly updated.
              </p>
              
              <p>
                We're proud to have played a part in countless success stories, from students achieving their 
                target grades to those who've gone on to pursue their dream careers. Every download, every 
                successful exam, and every grateful message from our users reinforces our commitment to this cause.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-8">Our Mission</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="p-6 bg-white rounded-xl shadow-md">
                <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="h-6 w-6 text-primary-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Accessibility</h3>
                <p className="text-gray-600">
                  Making quality educational resources freely accessible to students everywhere
                </p>
              </div>
              
              <div className="p-6 bg-white rounded-xl shadow-md">
                <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-6 w-6 text-primary-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Community</h3>
                <p className="text-gray-600">
                  Building a supportive community where students can learn and grow together
                </p>
              </div>
              
              <div className="p-6 bg-white rounded-xl shadow-md">
                <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target className="h-6 w-6 text-primary-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Excellence</h3>
                <p className="text-gray-600">
                  Continuously improving our platform to better serve our users' needs
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-8">The Team Behind Paperlords</h2>
            <p className="text-xl text-gray-600 mb-8">
              We're a dedicated team of educators, developers, and students who are passionate about 
              making education more accessible and effective.
            </p>
            <p className="text-gray-700">
              Our diverse backgrounds in education, technology, and student support allow us to 
              understand the unique challenges that students face and develop solutions that truly make a difference.
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default About;