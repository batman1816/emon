import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { BookOpen, Users, Download, Zap, MessageCircle, TrendingUp } from 'lucide-react';

const Homepage: React.FC = () => {
  const features = [
    {
      icon: BookOpen,
      title: 'Comprehensive Papers',
      description: 'Access thousands of IGCSE and IAL past papers, mark schemes, and specimen papers.',
    },
    {
      icon: Download,
      title: 'Instant Downloads',
      description: 'Download papers instantly with our fast, reliable file delivery system.',
    },
    {
      icon: Users,
      title: 'Community Driven',
      description: 'Join our active Discord community for study tips, discussions, and support.',
    },
    {
      icon: Zap,
      title: 'Always Updated',
      description: 'Latest papers uploaded as soon as they become available.',
    },
  ];

  const recentUploads = [
    { subject: 'Biology', level: 'IGCSE', session: 'Oct 2023', type: 'QP' },
    { subject: 'Mathematics', level: 'IAL', session: 'Oct 2023', type: 'MS' },
    { subject: 'Chemistry', level: 'IGCSE', session: 'Oct 2023', type: 'QP' },
    { subject: 'Physics', level: 'IAL', session: 'Oct 2023', type: 'MS' },
    { subject: 'English Literature', level: 'IGCSE', session: 'Oct 2023', type: 'QP' },
    { subject: 'Economics', level: 'IAL', session: 'Oct 2023', type: 'MS' },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
      },
    },
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-600 via-primary-700 to-primary-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Empowering Students
              <span className="block text-primary-200">Since 2018</span>
            </h1>
            <p className="text-xl md:text-2xl text-primary-100 mb-8 max-w-3xl mx-auto">
              Access thousands of IGCSE and IAL past papers, mark schemes, and resources. 
              Your academic success is our mission.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Link
                  to="/igcse"
                  className="inline-flex items-center px-8 py-4 bg-white text-primary-600 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-200"
                >
                  <BookOpen className="mr-2 h-5 w-5" />
                  Browse IGCSE Papers
                </Link>
              </motion.div>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Link
                  to="/ial"
                  className="inline-flex items-center px-8 py-4 bg-primary-500 text-white rounded-lg font-semibold hover:bg-primary-400 transition-colors duration-200 border-2 border-primary-400"
                >
                  <TrendingUp className="mr-2 h-5 w-5" />
                  Browse IAL Papers
                </Link>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Why Choose Paperlords?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We've been the trusted resource for students worldwide, providing comprehensive access to exam materials.
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
          >
            {features.map((feature, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                className="text-center p-6 rounded-xl bg-gray-50 hover:bg-gray-100 transition-colors duration-200"
                whileHover={{ y: -5 }}
              >
                <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-100 rounded-full mb-4">
                  <feature.icon className="h-8 w-8 text-primary-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Recent Uploads Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Recent Uploads</h2>
            <p className="text-xl text-gray-600">
              Stay updated with the latest past papers and mark schemes
            </p>
          </motion.div>

          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {recentUploads.map((upload, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow duration-200 p-6"
                whileHover={{ y: -2 }}
              >
                <div className="flex items-center justify-between mb-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    upload.level === 'IGCSE' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                  }`}>
                    {upload.level}
                  </span>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    upload.type === 'QP' ? 'bg-purple-100 text-purple-800' : 'bg-orange-100 text-orange-800'
                  }`}>
                    {upload.type}
                  </span>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{upload.subject}</h3>
                <p className="text-gray-600 mb-4">{upload.session}</p>
                <Link
                  to={`/${upload.level.toLowerCase()}/${upload.subject.toLowerCase().replace(/\s+/g, '-')}`}
                  className="inline-flex items-center text-primary-600 hover:text-primary-700 font-medium"
                >
                  View Papers
                  <svg className="ml-1 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Discord Section */}
      <section className="py-20 bg-indigo-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold text-white mb-4">Join Our Community</h2>
            <p className="text-xl text-indigo-100 mb-8 max-w-2xl mx-auto">
              Connect with fellow students, get study tips, and stay updated with the latest papers on our Discord server.
            </p>
            <motion.a
              href="https://discord.gg/paperlords"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-8 py-4 bg-white text-indigo-600 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-200"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              animate={{ scale: [1, 1.02, 1] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
            >
              <MessageCircle className="mr-2 h-5 w-5" />
              Join Discord Community
            </motion.a>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Homepage;