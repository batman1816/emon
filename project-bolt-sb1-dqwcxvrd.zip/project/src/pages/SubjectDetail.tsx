import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Download, FileText, Clock, AlertCircle } from 'lucide-react';
import { getSubjectByName, getSessionsBySubject, getPapersBySession } from '../data/mockData';

interface SubjectDetailProps {
  level: 'IGCSE' | 'IAL';
}

const SubjectDetail: React.FC<SubjectDetailProps> = ({ level }) => {
  const { subject: subjectParam } = useParams<{ subject: string }>();
  
  if (!subjectParam) {
    return <div>Subject not found</div>;
  }

  const subject = getSubjectByName(subjectParam, level);
  
  if (!subject) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Subject Not Found</h1>
          <Link
            to={`/${level.toLowerCase()}`}
            className="text-primary-600 hover:text-primary-700"
          >
            Back to {level} subjects
          </Link>
        </div>
      </div>
    );
  }

  const sessions = getSessionsBySubject(subject.id);
  const levelColor = level === 'IGCSE' ? 'green' : 'blue';

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
      },
    },
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className={`bg-gradient-to-r from-${levelColor}-600 to-${levelColor}-700 text-white py-16`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Link
              to={`/${level.toLowerCase()}`}
              className="inline-flex items-center text-white hover:text-gray-200 mb-6 transition-colors duration-200"
            >
              <ArrowLeft className="mr-2 h-5 w-5" />
              Back to {level} Subjects
            </Link>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              {level} {subject.name}
            </h1>
            <p className="text-xl text-gray-200">
              Subject Code: {subject.code} • {sessions.length} sessions available
            </p>
          </motion.div>
        </div>
      </section>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-8"
        >
          {sessions.map((session) => {
            const papers = getPapersBySession(session.id);
            const qpPaper = papers.find(p => p.type === 'QP');
            const msPaper = papers.find(p => p.type === 'MS');
            const samPaper = papers.find(p => p.type === 'SAM');

            return (
              <motion.div
                key={session.id}
                variants={itemVariants}
                className="bg-white rounded-xl shadow-md p-8"
              >
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-3">
                    <Clock className={`h-6 w-6 text-${levelColor}-600`} />
                    <h2 className="text-2xl font-bold text-gray-900">{session.session}</h2>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium bg-${levelColor}-100 text-${levelColor}-800`}>
                    {session.year}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Question Paper */}
                  <div className="p-6 border-2 border-dashed border-gray-200 rounded-lg">
                    <div className="text-center">
                      <FileText className={`h-12 w-12 text-${levelColor}-600 mx-auto mb-4`} />
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">Question Paper</h3>
                      {qpPaper?.available ? (
                        <motion.a
                          href={qpPaper.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={`inline-flex items-center px-4 py-2 bg-${levelColor}-600 text-white rounded-lg hover:bg-${levelColor}-700 transition-colors duration-200`}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <Download className="mr-2 h-4 w-4" />
                          Download QP
                        </motion.a>
                      ) : (
                        <div className="flex items-center justify-center space-x-2 text-gray-500">
                          <AlertCircle className="h-4 w-4" />
                          <span>Pending</span>
                        </div>
                      )}
                      {qpPaper?.fileName && (
                        <p className="text-sm text-gray-500 mt-2">{qpPaper.fileName}</p>
                      )}
                    </div>
                  </div>

                  {/* Mark Scheme */}
                  <div className="p-6 border-2 border-dashed border-gray-200 rounded-lg">
                    <div className="text-center">
                      <FileText className={`h-12 w-12 text-${levelColor}-600 mx-auto mb-4`} />
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">Mark Scheme</h3>
                      {msPaper?.available ? (
                        <motion.a
                          href={msPaper.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={`inline-flex items-center px-4 py-2 bg-${levelColor}-600 text-white rounded-lg hover:bg-${levelColor}-700 transition-colors duration-200`}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <Download className="mr-2 h-4 w-4" />
                          Download MS
                        </motion.a>
                      ) : (
                        <div className="flex items-center justify-center space-x-2 text-gray-500">
                          <AlertCircle className="h-4 w-4" />
                          <span>Pending</span>
                        </div>
                      )}
                      {msPaper?.fileName && (
                        <p className="text-sm text-gray-500 mt-2">{msPaper.fileName}</p>
                      )}
                    </div>
                  </div>

                  {/* Specimen Paper */}
                  <div className="p-6 border-2 border-dashed border-gray-200 rounded-lg">
                    <div className="text-center">
                      <FileText className={`h-12 w-12 text-${levelColor}-600 mx-auto mb-4`} />
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">Specimen</h3>
                      {samPaper?.available ? (
                        <motion.a
                          href={samPaper.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={`inline-flex items-center px-4 py-2 bg-${levelColor}-600 text-white rounded-lg hover:bg-${levelColor}-700 transition-colors duration-200`}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <Download className="mr-2 h-4 w-4" />
                          Download SAM
                        </motion.a>
                      ) : (
                        <div className="flex items-center justify-center space-x-2 text-gray-500">
                          <AlertCircle className="h-4 w-4" />
                          <span>Pending</span>
                        </div>
                      )}
                      {samPaper?.fileName && (
                        <p className="text-sm text-gray-500 mt-2">{samPaper.fileName}</p>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}

          {sessions.length === 0 && (
            <motion.div 
              variants={itemVariants}
              className="bg-white rounded-xl shadow-md p-8 text-center"
            >
              <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No Papers Available</h3>
              <p className="text-gray-600 mb-4">
                We don't have any papers for this subject yet. Check back soon!
              </p>
              <Link
                to="/search"
                className="inline-flex items-center px-6 py-3 bg-primary-600 text-white rounded-lg hover:bg-primary-700 transition-colors duration-200"
              >
                <FileText className="mr-2 h-5 w-5" />
                Search Other Papers
              </Link>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default SubjectDetail;