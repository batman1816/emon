import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { motion } from 'framer-motion';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import AdminRoute from './components/AdminRoute';
import Homepage from './pages/Homepage';
import About from './pages/About';
import IGCSE from './pages/IGCSE';
import IAL from './pages/IAL';
import SubjectDetail from './pages/SubjectDetail';
import Search from './pages/Search';
import NotFound from './pages/NotFound';
import Admin from './pages/Admin';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50 font-inter">
        <Routes>
          {/* Admin Route */}
          <Route 
            path="/admin" 
            element={
              <AdminRoute>
                <Admin />
              </AdminRoute>
            } 
          />
          
          {/* Public Routes */}
          <Route 
            path="/*" 
            element={
              <>
                <Navbar />
                <motion.main
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.3 }}
                >
                  <Routes>
                    <Route path="/" element={<Homepage />} />
                    <Route path="/about" element={<About />} />
                    <Route path="/igcse" element={<IGCSE />} />
                    <Route path="/ial" element={<IAL />} />
                    <Route path="/igcse/:subject" element={<SubjectDetail level="IGCSE" />} />
                    <Route path="/ial/:subject" element={<SubjectDetail level="IAL" />} />
                    <Route path="/search" element={<Search />} />
                    <Route path="/no-resource" element={<NotFound />} />
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </motion.main>
                <Footer />
              </>
            }
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App;