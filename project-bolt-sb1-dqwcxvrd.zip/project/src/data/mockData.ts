export interface Subject {
  id: string;
  name: string;
  level: 'IGCSE' | 'IAL';
  code: string;
}

export interface PaperSession {
  id: string;
  subjectId: string;
  session: string;
  year: number;
  month: string;
}

export interface Paper {
  id: string;
  sessionId: string;
  type: 'QP' | 'MS' | 'SAM';
  url: string;
  fileName: string;
  available: boolean;
}

export const subjects: Subject[] = [
  // IGCSE Subjects
  { id: '1', name: 'Biology', level: 'IGCSE', code: '0610' },
  { id: '2', name: 'Chemistry', level: 'IGCSE', code: '0620' },
  { id: '3', name: 'Physics', level: 'IGCSE', code: '0625' },
  { id: '4', name: 'Mathematics', level: 'IGCSE', code: '0580' },
  { id: '5', name: 'English Language', level: 'IGCSE', code: '0500' },
  { id: '6', name: 'English Literature', level: 'IGCSE', code: '0486' },
  { id: '7', name: 'Economics', level: 'IGCSE', code: '0455' },
  { id: '8', name: 'Business Studies', level: 'IGCSE', code: '0450' },
  { id: '9', name: 'Accounting', level: 'IGCSE', code: '0452' },
  { id: '10', name: 'Computer Science', level: 'IGCSE', code: '0478' },
  { id: '11', name: 'Geography', level: 'IGCSE', code: '0460' },
  { id: '12', name: 'History', level: 'IGCSE', code: '0470' },
  
  // IAL Subjects
  { id: '13', name: 'Biology', level: 'IAL', code: '9700' },
  { id: '14', name: 'Chemistry', level: 'IAL', code: '9701' },
  { id: '15', name: 'Physics', level: 'IAL', code: '9702' },
  { id: '16', name: 'Mathematics', level: 'IAL', code: '9709' },
  { id: '17', name: 'English Literature', level: 'IAL', code: '9695' },
  { id: '18', name: 'Economics', level: 'IAL', code: '9708' },
  { id: '19', name: 'Business', level: 'IAL', code: '9609' },
  { id: '20', name: 'Accounting', level: 'IAL', code: '9706' },
  { id: '21', name: 'Computer Science', level: 'IAL', code: '9618' },
  { id: '22', name: 'Geography', level: 'IAL', code: '9696' },
  { id: '23', name: 'History', level: 'IAL', code: '9489' },
  { id: '24', name: 'Psychology', level: 'IAL', code: '9698' },
];

export const paperSessions: PaperSession[] = [
  // IGCSE Biology Sessions
  { id: '1', subjectId: '1', session: 'Oct 2023', year: 2023, month: 'October' },
  { id: '2', subjectId: '1', session: 'June 2023', year: 2023, month: 'June' },
  { id: '3', subjectId: '1', session: 'Feb 2023', year: 2023, month: 'February' },
  
  // IGCSE Chemistry Sessions
  { id: '4', subjectId: '2', session: 'Oct 2023', year: 2023, month: 'October' },
  { id: '5', subjectId: '2', session: 'June 2023', year: 2023, month: 'June' },
  
  // IGCSE Physics Sessions
  { id: '6', subjectId: '3', session: 'Oct 2023', year: 2023, month: 'October' },
  { id: '7', subjectId: '3', session: 'June 2023', year: 2023, month: 'June' },
  
  // IGCSE Mathematics Sessions
  { id: '8', subjectId: '4', session: 'Oct 2023', year: 2023, month: 'October' },
  { id: '9', subjectId: '4', session: 'June 2023', year: 2023, month: 'June' },
  
  // IAL Biology Sessions
  { id: '10', subjectId: '13', session: 'Oct 2023', year: 2023, month: 'October' },
  { id: '11', subjectId: '13', session: 'June 2023', year: 2023, month: 'June' },
  
  // IAL Chemistry Sessions
  { id: '12', subjectId: '14', session: 'Oct 2023', year: 2023, month: 'October' },
  { id: '13', subjectId: '14', session: 'June 2023', year: 2023, month: 'June' },
  
  // IAL Physics Sessions
  { id: '14', subjectId: '15', session: 'Oct 2023', year: 2023, month: 'October' },
  { id: '15', subjectId: '15', session: 'June 2023', year: 2023, month: 'June' },
  
  // IAL Mathematics Sessions
  { id: '16', subjectId: '16', session: 'Oct 2023', year: 2023, month: 'October' },
  { id: '17', subjectId: '16', session: 'June 2023', year: 2023, month: 'June' },
];

export const papers: Paper[] = [
  // IGCSE Biology Oct 2023
  { id: '1', sessionId: '1', type: 'QP', url: '/papers/igcse-biology-oct-2023-qp.pdf', fileName: '0610_s23_qp_1.pdf', available: true },
  { id: '2', sessionId: '1', type: 'MS', url: '/papers/igcse-biology-oct-2023-ms.pdf', fileName: '0610_s23_ms_1.pdf', available: true },
  { id: '3', sessionId: '1', type: 'SAM', url: '/papers/igcse-biology-oct-2023-sam.pdf', fileName: '0610_s23_sam.pdf', available: false },
  
  // IGCSE Biology June 2023
  { id: '4', sessionId: '2', type: 'QP', url: '/papers/igcse-biology-june-2023-qp.pdf', fileName: '0610_s23_qp_2.pdf', available: true },
  { id: '5', sessionId: '2', type: 'MS', url: '/papers/igcse-biology-june-2023-ms.pdf', fileName: '0610_s23_ms_2.pdf', available: true },
  
  // IGCSE Chemistry Oct 2023
  { id: '6', sessionId: '4', type: 'QP', url: '/papers/igcse-chemistry-oct-2023-qp.pdf', fileName: '0620_s23_qp_1.pdf', available: true },
  { id: '7', sessionId: '4', type: 'MS', url: '/papers/igcse-chemistry-oct-2023-ms.pdf', fileName: '0620_s23_ms_1.pdf', available: true },
  
  // IAL Biology Oct 2023
  { id: '8', sessionId: '10', type: 'QP', url: '/papers/ial-biology-oct-2023-qp.pdf', fileName: '9700_s23_qp_1.pdf', available: true },
  { id: '9', sessionId: '10', type: 'MS', url: '/papers/ial-biology-oct-2023-ms.pdf', fileName: '9700_s23_ms_1.pdf', available: true },
  
  // IAL Mathematics Oct 2023
  { id: '10', sessionId: '16', type: 'QP', url: '/papers/ial-mathematics-oct-2023-qp.pdf', fileName: '9709_s23_qp_1.pdf', available: true },
  { id: '11', sessionId: '16', type: 'MS', url: '/papers/ial-mathematics-oct-2023-ms.pdf', fileName: '9709_s23_ms_1.pdf', available: false },
];

export const getSubjectsByLevel = (level: 'IGCSE' | 'IAL') => {
  return subjects.filter(subject => subject.level === level);
};

export const getSubjectByName = (name: string, level: 'IGCSE' | 'IAL') => {
  const normalizedName = name.toLowerCase().replace(/-/g, ' ');
  return subjects.find(subject => 
    subject.name.toLowerCase() === normalizedName && subject.level === level
  );
};

export const getSessionsBySubject = (subjectId: string) => {
  return paperSessions.filter(session => session.subjectId === subjectId);
};

export const getPapersBySession = (sessionId: string) => {
  return papers.filter(paper => paper.sessionId === sessionId);
};

export const searchPapers = (query: string) => {
  const normalizedQuery = query.toLowerCase();
  const results = [];
  
  for (const subject of subjects) {
    if (subject.name.toLowerCase().includes(normalizedQuery)) {
      const sessions = getSessionsBySubject(subject.id);
      for (const session of sessions) {
        const sessionPapers = getPapersBySession(session.id);
        for (const paper of sessionPapers) {
          if (paper.available) {
            results.push({
              subject: subject.name,
              level: subject.level,
              session: session.session,
              type: paper.type,
              url: paper.url,
              fileName: paper.fileName,
            });
          }
        }
      }
    }
  }
  
  return results;
};